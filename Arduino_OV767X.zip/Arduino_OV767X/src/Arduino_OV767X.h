// SPDX-License-Identifier: GPL-2.0-only
/*
 * This file is part of the Arduino_OX767X library.
 * Copyright (c) 2020 Arduino SA. All rights reserved.
 */

#ifndef _ARUDINO_OV767X_H_
#define _ARUDINO_OV767X_H_

#include "OV767X.h"

#endif
